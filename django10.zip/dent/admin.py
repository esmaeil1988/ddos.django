from django.contrib import admin
from.models import doctor
from.models import contact
from.models import news
# Register your models here.
admin.site.register(doctor)
admin.site.register(contact)
admin.site.register(news)